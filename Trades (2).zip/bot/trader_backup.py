import asyncio
import logging
import pandas as pd
import math
from datetime import time, datetime

from bot.api import CapitalComAPI
from bot.database import DatabaseManager
from bot.market_time import MarketTimeManager
from bot.settings import TradingBotSettings
from bot.ai_system import HybridIntelligentSystem
from bot.data_downloader import DataDownloader
from capitalcom.client import ResolutionType

# Import GOSPEL Brains system
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from Brains.ai_system import HybridIntelligentSystem as BrainsAI

logger = logging.getLogger(__name__)

class TradingBot:
    """Main trading bot class with complete Hybrid Intelligent System"""
    
    def __init__(self):
        self.settings = TradingBotSettings()
        self.api = CapitalComAPI(self.settings)
        self.db_manager = DatabaseManager()
        self.market_timer = MarketTimeManager(self.settings)
        self.ai_system = HybridIntelligentSystem()
        self.downloader = DataDownloader(self.api, self.db_manager)
        self.is_running = False
        self.api_connected = False
        self.current_account = None
        self.market_info = {}
        self.positions = []
        self.balance_info = {}
        self.last_trade_date = None
        self.current_position = None
        self.trade_history = []
        self.winning_trades = 0
        self.losing_trades = 0
        self.total_fees = 0
        self.keepalive_task = None
        self.downloader_task = None
        
        # Timer-based trading flags
        self.use_timer_based_trading = True  # Enable timer-based trading by default
        self.positions_closed_today = False
        self.trade_analyzed_today = False
        
        # Timer settings from config
        self.seconds_before_close_to_exit = self.settings.getint(
            "BOT_CONFIG", "seconds_before_close_to_exit", 30
        )
        self.seconds_before_close_to_trade = self.settings.getint(
            "BOT_CONFIG", "seconds_before_close_to_trade", 15
        )
        
    async def initialize(self) -> bool:
        """Initialize the trading bot"""
        try:
            # Check if API is already connected (shared from main)
            if not self.api_connected and hasattr(self.api, 'client') and self.api.client:
                self.api_connected = True
                logger.info("Using existing API connection")
            elif not self.api_connected:
                if not await self.api.authenticate():
                    return False
                self.api_connected = True
            
            accounts = await self.api.get_accounts()
            if not accounts:
                logger.error("No accounts found")
                return False
            
            env = self.api.environment
            account_id = self.settings.get("ENV_ACCOUNTS", env, "") or self.settings.get("CREDENTIALS", "account_id")
            target_account = None

            if account_id:
                target_account = next((acc for acc in accounts if acc.get("accountId") == account_id), None)
                if not target_account:
                    logger.warning(f"Account {account_id} not found, using first available account.")

            if not target_account:
                target_account = accounts[0]

            self.current_account = target_account
            account_id_to_switch = self.current_account.get("accountId")
            
            if not await self.api.switch_account(account_id_to_switch):
                 return False

            logger.info(f"Using account: {self.current_account.get('accountName', 'Unknown')}")
            
            epic = self.settings.get("BOT_CONFIG", "epic", "TECL")
            self.market_info = await self.api.get_market_info(epic)

            # Start continuous data download (cancel old if exists)
            if self.downloader_task and not self.downloader_task.done():
                self.downloader_task.cancel()
            self.downloader_task = asyncio.create_task(
                self.downloader.continuous_download(epic, ResolutionType.MINUTE_5, 300)
            )
            # Start keepalive pings every 4 minutes
            self.keepalive_task = asyncio.create_task(self._keepalive_loop())
            
            return True
            
        except Exception as e:
            logger.error(f"Initialization error: {e}")
            return False
    
    async def update_data(self):
        """Update all bot data"""
        try:
            self.positions = await self.api.get_positions()
            
            if self.current_account:
                accounts = await self.api.get_accounts()
                current_account_id = self.current_account.get("accountId")
                updated_account = next((acc for acc in accounts if acc.get("accountId") == current_account_id), None)
                if updated_account:
                    self.current_account = updated_account
                    self.balance_info = updated_account.get("balance", {})
            
            epic = self.settings.get("BOT_CONFIG", "epic", "TECL")
            market_data = await self.api.get_market_info(epic)
            if market_data:
                self.market_info = market_data
                # Log minimal market info snapshot for troubleshooting
                logger.debug(f"Market snapshot updated for {epic}")
                
        except Exception as e:
            logger.error(f"Error updating data: {e}")

    async def run(self):
        """Main trading loop with timer-based execution"""
        self.is_running = True
        
        if self.use_timer_based_trading:
            logger.info("="*60)
            logger.info("BOT STARTED SUCCESSFULLY - TIMER-BASED MODE ACTIVE")
            logger.info("="*60)
            logger.info(f"Configuration:")
            logger.info(f"  - Epic: {self.settings.get('BOT_CONFIG', 'epic', 'TECL')}")
            logger.info(f"  - Close positions: {self.seconds_before_close_to_exit}s before market close")
            logger.info(f"  - Analyze & trade: {self.seconds_before_close_to_trade}s before market close")
            logger.info(f"  - Investment: {self.settings.getfloat('BOT_CONFIG', 'investment_percentage', 99)}% of available balance")
            logger.info(f"  - Leverage: {self.settings.getfloat('BOT_CONFIG', 'leverage', 1.0)}x")
            logger.info("="*60)
        else:
            logger.info("Trading bot started with Hybrid Intelligent System")
        
        status_counter = 0  # Counter for periodic status updates
        
        while self.is_running:
            await self.update_data()
            
            if self.use_timer_based_trading:
                # Get current market event
                market_event = self.market_timer.get_next_market_event(self.market_info)
                
                # Show status every 30 seconds
                status_counter += 1
                if status_counter >= 30:
                    if market_event and market_event.get('is_open'):
                        time_until = int(market_event.get('time_until_close', 0))
                        logger.info(f"BOT MONITORING: Market OPEN - Waiting for T-{self.seconds_before_close_to_exit}s (currently {time_until}s until close)")
                    elif market_event:
                        hours_until_open = market_event.get('time_until_open', 0) / 3600
                        logger.info(f"BOT MONITORING: Market CLOSED - Opens in {hours_until_open:.1f} hours. Ready to trade when market opens.")
                    status_counter = 0
                
                # Execute timer-based strategy
                await self.execute_timer_based_strategy(market_event)
                
                # Check every second for precise timing
                await asyncio.sleep(1)
            else:
                # Fallback to original strategy
                await self.execute_hybrid_intelligent_strategy()
                await asyncio.sleep(5)

    async def _keepalive_loop(self):
        while True:
            try:
                await asyncio.sleep(240)
                await self.api.keepalive()
            except Exception as e:
                logger.warning(f"Keepalive loop error: {e}")

    async def execute_timer_based_strategy(self, market_event):
        """Execute timer-based trading strategy - 30s close, 15s trade"""
        try:
            # Check if market is open
            if not market_event.get('is_open', False):
                # Reset flags when market is closed
                if self.positions_closed_today or self.trade_analyzed_today:
                    logger.info("Market closed - resetting daily flags")
                    self.positions_closed_today = False
                    self.trade_analyzed_today = False
                return
            
            # Get time until market close
            time_until_close = market_event.get('time_until_seconds', float('inf'))
            current_date = datetime.now().date()
            
            # Only trade once per day
            if current_date == self.last_trade_date and self.trade_analyzed_today:
                return
            
            # Log countdown in critical window
            if time_until_close <= 60 and time_until_close > 0:
                if int(time_until_close) % 10 == 0:  # Log every 10 seconds
                    logger.info(f"Market closes in {time_until_close:.0f} seconds")
            
            # STEP 1: Close all positions at T-30 seconds
            if (time_until_close <= self.seconds_before_close_to_exit and 
                not self.positions_closed_today):
                
                logger.info(f"CLOSING ALL POSITIONS (T-{time_until_close:.0f}s)")
                await self.close_all_positions_timer()
                self.positions_closed_today = True
            
            # STEP 2: Analyze and potentially trade at T-15 seconds
            elif (time_until_close <= self.seconds_before_close_to_trade and 
                  not self.trade_analyzed_today and
                  self.positions_closed_today):  # Only after positions are closed
                
                logger.info(f"RUNNING BRAINS ANALYSIS (T-{time_until_close:.0f}s)")
                await self.analyze_and_trade_timer()
                self.trade_analyzed_today = True
                self.last_trade_date = current_date
                
        except Exception as e:
            logger.error(f"Error in timer strategy: {e}", exc_info=True)
    
    async def close_all_positions_timer(self):
        """Close all open positions for timer-based trading"""
        try:
            positions = await self.api.get_positions()
            
            if not positions:
                logger.info("No open positions to close")
                return
            
            logger.info(f"Found {len(positions)} position(s) to close")
            
            for position in positions:
                try:
                    pos_data = position.get('position', {})
                    deal_id = pos_data.get('dealId')
                    epic = position.get('market', {}).get('epic', 'Unknown')
                    direction = pos_data.get('direction')
                    size = pos_data.get('size')
                    
                    if not deal_id:
                        continue
                    
                    logger.info(f"Closing: {epic} {direction} {size} (Deal: {deal_id})")
                    result = await self.api.close_position(deal_id)
                    
                    if result:
                        logger.info(f"Closed position {deal_id}")
                    else:
                        logger.error(f"Failed to close {deal_id}")
                        
                    await asyncio.sleep(0.5)  # Avoid rate limiting
                    
                except Exception as e:
                    logger.error(f"Error closing position: {e}")
            
            logger.info("All positions closed")
            
        except Exception as e:
            logger.error(f"Error closing positions: {e}", exc_info=True)
    
    async def analyze_and_trade_timer(self):
        """Run GOSPEL Brains analysis and execute trade if approved"""
        try:
            # Get market info
            epic = self.settings.get("BOT_CONFIG", "epic", "TECL")
            self.market_info = await self.api.get_market_info(epic)
            
            if not self.market_info:
                logger.error(f"Failed to fetch market info for {epic}")
                return
            
            # Get dealing rules
            dealing_rules = self.market_info.get('dealingRules', {})
            if not dealing_rules:
                logger.error("No dealing rules found")
                return
            
            # Prepare data for Brains analysis
            candles = self.db_manager.get_candles(epic, limit=200)
            
            if len(candles) < 50:
                logger.warning(f"Insufficient data: {len(candles)} candles (need 50+)")
                return
            
            # Convert to DataFrame for Brains
            df = pd.DataFrame(candles, columns=["epic", "timestamp", "open", "high", "low", "close", "volume"])
            df["timestamp"] = pd.to_datetime(df["timestamp"])
            df.set_index("timestamp", inplace=True)
            
            # Use GOSPEL Brains AI
            brains_ai = BrainsAI()
            historical_data = brains_ai.calculate_technical_indicators(df.copy())
            
            current_date = datetime.now().date()
            day_data = df[df.index.date == current_date].copy() if not df.empty else pd.DataFrame()
            
            # Run GOSPEL AI analysis
            logger.info("Running Brains AI analysis...")
            ai_analysis = brains_ai.analyze_market_conditions(
                day_data, 
                historical_data, 
                datetime.now()
            )
            
            logger.info(f"BRAINS DECISION:")
            logger.info(f"  Signal: {ai_analysis['trade_signal']}")
            logger.info(f"  Confidence: {ai_analysis['confidence']:.2%}")
            logger.info(f"  Direction: {ai_analysis['direction']}")
            
            # Check confidence threshold
            confidence_threshold = self.settings.getfloat("BOT_CONFIG", "ai_confidence_threshold", 30.0) / 100.0
            
            if ai_analysis['trade_signal'] == 'hold':
                logger.info("No trade - AI signal is HOLD")
                return
            
            if ai_analysis['confidence'] < confidence_threshold:
                logger.info(f"No trade - Confidence {ai_analysis['confidence']:.2%} < {confidence_threshold:.2%}")
                return
            
            # Execute trade
            logger.info("Trade conditions met - executing position")
            await self.create_position_timer(ai_analysis, dealing_rules)
            
        except Exception as e:
            logger.error(f"Error in Brains analysis: {e}", exc_info=True)
    
    async def create_position_timer(self, ai_analysis, dealing_rules):
        """Create position with full dealing rules compliance"""
        try:
            # Get market prices
            snapshot = self.market_info.get('snapshot', {})
            bid = snapshot.get('bid')
            offer = snapshot.get('offer')
            
            if not bid or not offer:
                logger.error(f"Invalid prices - Bid: {bid}, Offer: {offer}")
                return
            
            # Professional price selection
            entry_price = offer if ai_analysis['direction'] == 'long' else bid
            
            logger.info(f"Prices - Bid: {bid:.2f}, Offer: {offer:.2f}, Entry: {entry_price:.2f}")
            
            # Extract dealing rules
            min_size = dealing_rules.get('minDealSize', {}).get('value', 0.1)
            max_size = dealing_rules.get('maxDealSize', {}).get('value', 1000)
            increment = dealing_rules.get('minSizeIncrement', {}).get('value', 0.1)
            
            logger.info(f"Dealing Rules: Min={min_size}, Max={max_size}, Increment={increment}")
            
            # Get account balance
            accounts = await self.api.get_accounts()
            if not accounts:
                logger.error("No accounts available")
                return
            
            account = accounts[0]
            available = account.get('balance', {}).get('available', 0)
            
            if available <= 0:
                logger.error(f"Insufficient balance: ${available:.2f}")
                return
            
            logger.info(f"Available Balance: ${available:.2f}")
            
            # Calculate position size (EXACT from legacy)
            leverage = self.settings.getfloat("BOT_CONFIG", "leverage", 4.0)
            investment_pct = self.settings.getfloat("BOT_CONFIG", "investment_pct", 99.0)
            
            raw_size = (available * (investment_pct / 100.0) * leverage) / entry_price
            
            logger.info(f"Position calc: ${available:.2f} * {investment_pct}% * {leverage}x / ${entry_price:.2f} = {raw_size:.4f}")
            
            # Apply dealing rules
            if raw_size < min_size:
                trade_size = min_size
            elif raw_size > max_size:
                trade_size = max_size
            else:
                trade_size = raw_size
            
            # Floor to increment
            trade_size = math.floor(trade_size / increment) * increment
            
            if trade_size < min_size:
                logger.error(f"Final size {trade_size} below minimum {min_size}")
                return
            
            logger.info(f"Final Size: {trade_size}")
            
            # Calculate stop loss
            stop_loss_pct = self.settings.getfloat("BOT_CONFIG", "stop_loss_pct", 2.0)
            
            if ai_analysis['direction'] == 'long':
                stop_level = entry_price * (1 - stop_loss_pct / 100.0)
                direction = 'BUY'
            else:
                stop_level = entry_price * (1 + stop_loss_pct / 100.0)
                direction = 'SELL'
            
            logger.info(f"Stop Loss: {stop_loss_pct}% at ${stop_level:.2f}")
            
            # Create position
            epic = self.settings.get("BOT_CONFIG", "epic", "TECL")
            logger.info(f"Sending: {direction} {trade_size} {epic} @ {entry_price:.2f}")
            
            result = await self.api.create_position(
                epic=epic,
                direction=direction,
                size=trade_size,
                stop_level=stop_level
            )
            
            if result:
                logger.info(f"TRADE EXECUTED: {direction} {trade_size} @ ${entry_price:.2f}, Stop: ${stop_level:.2f}")
                if isinstance(result, dict):
                    deal_ref = result.get('dealReference', 'N/A')
                    logger.info(f"Deal Reference: {deal_ref}")
            else:
                logger.error("Trade execution failed")
                
        except Exception as e:
            logger.error(f"Error creating position: {e}", exc_info=True)
    
    async def execute_hybrid_intelligent_strategy(self):
        """Execute the complete Hybrid Intelligent Trading Strategy"""
        market_event = self.market_timer.get_next_market_event(self.market_info)
        now = self.market_timer.get_current_time_market()
        current_date = now.date()

        if not market_event.get("is_open"):
            return

        epic = self.settings.get("BOT_CONFIG", "epic", "TECL")
        
        # Get day data (simulated as we don't have intraday data in real-time)
        day_data = pd.DataFrame()  # This would be populated with real intraday data
        
        # Get historical data for AI analysis
        candles = self.db_manager.get_candles(epic, limit=200)
        if len(candles) < 50:
            logger.warning("Not enough historical data for AI analysis")
            return

        df = pd.DataFrame(candles, columns=["epic", "timestamp", "open", "high", "low", "close", "volume"])
        df["timestamp"] = pd.to_datetime(df["timestamp"])
        df.set_index("timestamp", inplace=True)

        # Calculate technical indicators
        historical_data = self.ai_system.calculate_technical_indicators(df)

        # Market times (matching the uploaded strategy exactly)
        analysis_time = time(15, 30)
        entry_time = time(15, 59, 45)
        exit_time = time(15, 59, 30)

        # Step 1: Close existing position if exists
        if self.current_position is not None:
            await self.close_current_position(day_data, exit_time, current_date)

        # Step 2: AI Analysis for new position (only during analysis time window)
        if now.time() >= analysis_time and now.date() != self.last_trade_date:
            ai_analysis = self.ai_system.analyze_market_conditions(day_data, historical_data, current_date)
            
            logger.info(f"AI Analysis: {ai_analysis}")

            # Step 3: Decision to trade based on AI analysis and confidence threshold
            confidence_threshold = self.settings.getfloat("BOT_CONFIG", "ai_confidence_threshold", 30.0) / 100.0
            
            if (ai_analysis['trade_signal'] in ['buy', 'sell'] and 
                ai_analysis['confidence'] > confidence_threshold and
                now.time() >= entry_time):
                
                await self.create_new_position(ai_analysis, current_date, entry_time)
                self.last_trade_date = current_date

    async def close_current_position(self, day_data, exit_time, current_date):
        """Close existing position with stop-loss monitoring"""
        try:
            stop_loss_pct = self.settings.getfloat("BOT_CONFIG", "stop_loss_pct", 2.0)
            
            # Check if stopped out during the day (in real implementation, this would check intraday data)
            stop_hit, stop_price, stop_time = self.ai_system.check_stop_loss_hit(
                day_data, self.current_position['entry_price'], self.current_position['entry_time'], 
                self.current_position['direction'], stop_loss_pct
            )
            
            if stop_hit:
                exit_price = stop_price
                exit_reason = f'stop_loss_{stop_loss_pct}%'
                logger.info(f"Position stopped out at {stop_price}")
            else:
                # Get current market price for exit
                epic = self.settings.get("BOT_CONFIG", "epic", "TECL")
                market_data = await self.api.get_market_info(epic)
                if market_data and 'snapshot' in market_data:
                    exit_price = market_data['snapshot']['bid']
                else:
                    exit_price = self.current_position['entry_price']
                exit_reason = 'scheduled_exit'
            
            # Calculate P&L
            if self.current_position['direction'] == 'long':
                gross_return = (exit_price - self.current_position['entry_price']) / self.current_position['entry_price']
            else:
                gross_return = (self.current_position['entry_price'] - exit_price) / self.current_position['entry_price']
            
            gross_pnl = self.current_position['position_size'] * gross_return
            trade_costs = self.ai_system.calculate_trading_costs(
                self.current_position['position_size'], 
                self.current_position['direction'], 
                is_overnight=True
            )
            net_pnl = gross_pnl - trade_costs
            
            # Update balance (simulated)
            self.total_fees += trade_costs
            
            if net_pnl > 0:
                self.winning_trades += 1
            else:
                self.losing_trades += 1
            
            # Record trade
            trade_record = {
                'entry_date': self.current_position['entry_date'],
                'exit_date': current_date,
                'direction': self.current_position['direction'],
                'entry_price': self.current_position['entry_price'],
                'exit_price': exit_price,
                'position_size': self.current_position['position_size'],
                'gross_pnl': gross_pnl,
                'net_pnl': net_pnl,
                'trade_costs': trade_costs,
                'exit_reason': exit_reason,
                'ai_confidence': self.current_position.get('ai_confidence', 0)
            }
            self.trade_history.append(trade_record)
            
            logger.info(f"Position closed: {trade_record}")
            
            # Close position via API
            for position in self.positions:
                await self.api.close_position(position["position"]["dealId"])
            
            self.current_position = None
            
        except Exception as e:
            logger.error(f"Error closing position: {e}")

    async def create_new_position(self, ai_analysis, current_date, entry_time):
        """Create new position based on AI analysis"""
        try:
            epic = self.settings.get("BOT_CONFIG", "epic", "TECL")
            
            # Get current market price
            market_data = await self.api.get_market_info(epic)
            if not market_data or 'snapshot' not in market_data:
                logger.warning("Could not get market data for entry")
                return
            
            entry_price = market_data['snapshot']['offer']  # Use offer price for entry
            
            # Calculate position size
            leverage = self.settings.getfloat("BOT_CONFIG", "leverage", 4.0)
            investment_pct = self.settings.getfloat("BOT_CONFIG", "investment_pct", 99.0) / 100.0
            balance = self.balance_info.get("available", 0)
            
            if balance <= 0:
                logger.warning("No available balance for trading")
                return
            
            investment_amount = balance * investment_pct
            position_size = investment_amount * leverage
            
            # Calculate stop loss
            stop_loss_pct = self.settings.getfloat("BOT_CONFIG", "stop_loss_pct", 2.0)
            stop_level = None
            if ai_analysis['direction'] == 'long':
                stop_level = entry_price * (1 - stop_loss_pct / 100)
            else:
                stop_level = entry_price * (1 + stop_loss_pct / 100)
            
            # Create position via API
            position_result = await self.api.create_position(
                epic, 
                ai_analysis['direction'], 
                position_size, 
                stop_level
            )
            
            if position_result:
                # Store current position details
                self.current_position = {
                    'entry_date': current_date,
                    'entry_time': entry_time,
                    'direction': ai_analysis['direction'],
                    'entry_price': entry_price,
                    'position_size': position_size,
                    'leverage': leverage,
                    'ai_confidence': ai_analysis['confidence'],
                    'ai_reasoning': ai_analysis['reasoning'],
                    'stop_level': stop_level
                }
                
                logger.info(f"New position created: {self.current_position}")
            else:
                logger.error("Failed to create position via API")
                
        except Exception as e:
            logger.error(f"Error creating position: {e}")

    async def simulate_market_close(self):
        """Simulate REAL market conditions - create trade, wait, then close"""
        try:
            logger.info("="*60)
            logger.info("SIMULATION MODE: Real conditions test initiated")
            logger.info("="*60)
            
            # STEP 1: Check if we have open positions
            positions = await self.api.get_positions()
            
            if not positions or len(positions) == 0:
                # No positions - CREATE ONE FIRST
                logger.info("SIMULATION: No open positions found - creating test position")
                
                # Get market info
                epic = self.settings.get("BOT_CONFIG", "epic", "TECL")
                self.market_info = await self.api.get_market_info(epic)
                
                if not self.market_info:
                    logger.error(f"SIMULATION: Failed to get market info for {epic}")
                    return False
                
                dealing_rules = self.market_info.get('dealingRules', {})
                if not dealing_rules:
                    logger.error("SIMULATION: No dealing rules found")
                    return False
                
                # Get direction from settings
                direction_setting = self.settings.get("BOT_CONFIG", "direction", "long")
                
                # Create fake AI decision
                fake_ai_analysis = {
                    'trade_signal': 'buy' if direction_setting == 'long' else 'sell',
                    'confidence': 1.0,
                    'direction': direction_setting
                }
                
                logger.info(f"SIMULATION: Creating {direction_setting.upper()} position")
                
                # Create the position
                await self.create_position_timer(fake_ai_analysis, dealing_rules)
                
                # Wait for position to be established
                await asyncio.sleep(2)
                
                # Refresh positions
                positions = await self.api.get_positions()
                
                if not positions:
                    logger.error("SIMULATION: Failed to create position")
                    return False
                    
                logger.info(f"SIMULATION: Position created successfully - {len(positions)} position(s) open")
            else:
                logger.info(f"SIMULATION: Found {len(positions)} existing position(s)")
            
            # STEP 2: Let it run for 5 seconds (simulating market time)
            logger.info("SIMULATION: Simulating market time - position running...")
            for i in range(5, 0, -1):
                logger.info(f"SIMULATION: Market closing in {i}...")
                await asyncio.sleep(1)
            
            # STEP 3: Now simulate market close - close all positions
            logger.info("="*60)
            logger.info("SIMULATION: MARKET CLOSE - Closing all positions")
            logger.info("="*60)
            
            # Reset flags to allow closing
            self.positions_closed_today = False
            
            # Close all positions
            await self.close_all_positions_timer()
            
            # STEP 4: Create next day's trade (as would happen at T-15s)
            logger.info("SIMULATION: Creating next session's trade...")
            await asyncio.sleep(2)
            
            # Reset flags for new trade
            self.trade_analyzed_today = False
            
            # Get fresh market info
            self.market_info = await self.api.get_market_info(epic)
            
            if self.market_info:
                dealing_rules = self.market_info.get('dealingRules', {})
                if dealing_rules:
                    # Create next trade
                    fake_ai_analysis = {
                        'trade_signal': 'buy' if direction_setting == 'long' else 'sell',
                        'confidence': 1.0,
                        'direction': direction_setting
                    }
                    
                    logger.info("SIMULATION: Creating next session's position")
                    await self.create_position_timer(fake_ai_analysis, dealing_rules)
                    
                    # Mark as completed
                    self.trade_analyzed_today = True
                    self.last_trade_date = datetime.now().date()
            
            # Log completion
            logger.info("="*60)
            logger.info("SIMULATION: Complete! Simulated full market cycle:")
            logger.info("  1. Created/verified position")
            logger.info("  2. Let it run for 5 seconds")
            logger.info("  3. Closed at 'market close'")
            logger.info("  4. Created next session's position")
            logger.info("Bot will now wait for next real market session")
            logger.info("="*60)
            
            return True
            
        except Exception as e:
            logger.error(f"SIMULATION ERROR: {e}", exc_info=True)
            return False
    
    def stop(self):
        """Stop the trading bot"""
        self.is_running = False
        logger.info("Trading bot stopped")
        if self.keepalive_task:
            self.keepalive_task.cancel()
        if self.downloader_task:
            self.downloader_task.cancel()
        
        # Log final statistics
        total_trades = self.winning_trades + self.losing_trades
        if total_trades > 0:
            win_rate = self.winning_trades / total_trades * 100
            logger.info(f"Final Stats - Total Trades: {total_trades}, Win Rate: {win_rate:.1f}%, Total Fees: ${self.total_fees:.2f}")
